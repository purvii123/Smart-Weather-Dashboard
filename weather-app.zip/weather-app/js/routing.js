// ============================================================
// js/routing.js — A* Pathfinding with Haversine Heuristic
// ============================================================
//
// FIX: The original heuristic was h(n) = temperature, which is
// NOT admissible (temperature ≠ graph distance → not A*).
//
// FIX APPLIED: h(n) = haversine distance (km) from node n to goal.
// This IS admissible because the straight-line distance never
// overestimates the actual path cost.
//
// FIX: Delhi is no longer the only valid origin — user can pick any
// city in the graph as both start and end.

const Routing = (() => {

  // Geographic coordinates (lat, lng) for each city in the graph.
  const COORDS = {
    'Delhi':      [28.61, 77.21],
    'Chandigarh': [30.73, 76.78],
    'Shimla':     [31.10, 77.17],
    'Manali':     [32.24, 77.19],
    'Amritsar':   [31.63, 74.87],
    'Ludhiana':   [30.90, 75.85],
    'Jaipur':     [26.92, 75.82],
    'Ahmedabad':  [23.03, 72.58],
    'Mumbai':     [19.08, 72.88],
    'Goa':        [15.30, 74.12],
    'Pune':       [18.52, 73.85],
    'Hyderabad':  [17.38, 78.49],
    'Bangalore':  [12.97, 77.59],
    'Chennai':    [13.08, 80.27],
    'Dehradun':   [30.32, 78.03],
    'Haridwar':   [29.94, 78.16],
    'Jammu':      [32.73, 74.87],
    'Srinagar':   [34.08, 74.80],
    'Kolkata':    [22.57, 88.36],
    'Lucknow':    [26.85, 80.95],
  };

  // Adjacency list — undirected graph (each edge is bidirectional)
  const GRAPH = {
    'Delhi':      ['Chandigarh', 'Ludhiana', 'Jaipur', 'Lucknow', 'Dehradun'],
    'Chandigarh': ['Delhi', 'Shimla', 'Ludhiana', 'Jammu'],
    'Shimla':     ['Chandigarh', 'Manali'],
    'Manali':     ['Shimla'],
    'Ludhiana':   ['Delhi', 'Chandigarh', 'Amritsar'],
    'Amritsar':   ['Ludhiana', 'Jammu'],
    'Jammu':      ['Amritsar', 'Chandigarh', 'Srinagar'],
    'Srinagar':   ['Jammu'],
    'Jaipur':     ['Delhi', 'Ahmedabad'],
    'Ahmedabad':  ['Jaipur', 'Mumbai'],
    'Mumbai':     ['Ahmedabad', 'Goa', 'Pune'],
    'Goa':        ['Mumbai'],
    'Pune':       ['Mumbai', 'Hyderabad'],
    'Hyderabad':  ['Pune', 'Bangalore', 'Chennai', 'Kolkata'],
    'Bangalore':  ['Hyderabad', 'Chennai'],
    'Chennai':    ['Bangalore', 'Hyderabad'],
    'Dehradun':   ['Delhi', 'Haridwar'],
    'Haridwar':   ['Dehradun'],
    'Lucknow':    ['Delhi', 'Kolkata'],
    'Kolkata':    ['Lucknow', 'Hyderabad'],
  };

  // ---- Haversine great-circle distance (km) ----
  // This gives an admissible heuristic: straight-line ≤ road distance.
  function _haversine(cityA, cityB) {
    const cA = COORDS[cityA];
    const cB = COORDS[cityB];
    if (!cA || !cB) return 0;

    const R = 6371; // Earth radius km
    const dLat = (cB[0] - cA[0]) * Math.PI / 180;
    const dLon = (cB[1] - cA[1]) * Math.PI / 180;
    const lat1  = cA[0] * Math.PI / 180;
    const lat2  = cB[0] * Math.PI / 180;

    const a = Math.sin(dLat / 2) ** 2 +
              Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  // ---- A* Search ----
  // h(n) = haversine(n, goal) — admissible ✓
  // g(n) = cumulative haversine cost along the path
  function aStar(start, goal) {
    if (start === goal) return { path: [start], distance: 0 };

    if (!GRAPH[start]) return { path: [], error: `"${start}" not in route graph` };
    if (!GRAPH[goal])  return { path: [], error: `"${goal}" not in route graph` };

    const open    = new Set([start]);
    const cameFrom = {};
    const gScore  = {};
    const fScore  = {};

    for (const city of Object.keys(GRAPH)) {
      gScore[city] = Infinity;
      fScore[city] = Infinity;
    }
    gScore[start] = 0;
    fScore[start] = _haversine(start, goal);

    while (open.size > 0) {
      // Pick open node with lowest fScore
      let current = null;
      for (const city of open) {
        if (current === null || fScore[city] < fScore[current]) current = city;
      }

      if (current === goal) {
        // Reconstruct path
        const path = [];
        let node = goal;
        while (node) { path.unshift(node); node = cameFrom[node]; }

        const totalKm = Math.round(_haversine(path[0], path[path.length - 1]));
        return { path, distance: totalKm };
      }

      open.delete(current);

      for (const neighbour of (GRAPH[current] || [])) {
        const tentativeG = gScore[current] + _haversine(current, neighbour);

        if (tentativeG < (gScore[neighbour] ?? Infinity)) {
          cameFrom[neighbour] = current;
          gScore[neighbour]   = tentativeG;
          fScore[neighbour]   = tentativeG + _haversine(neighbour, goal);
          open.add(neighbour);
        }
      }
    }

    return { path: [], error: `No route found from "${start}" to "${goal}"` };
  }

  function getCities() { return Object.keys(GRAPH); }

  return { aStar, getCities };
})();
