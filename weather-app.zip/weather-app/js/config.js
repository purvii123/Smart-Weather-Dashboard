// ============================================================
// js/config.js — API Key Management
// ============================================================
// Stores the OpenWeatherMap API key in localStorage.
// The key is ONLY sent to api.openweathermap.org — nowhere else.

const Config = (() => {
  const KEY_STORE = 'owm_api_key';
  const BASE_URL  = 'https://api.openweathermap.org/data/2.5';

  function getKey()         { return localStorage.getItem(KEY_STORE) || ''; }
  function setKey(k)        { localStorage.setItem(KEY_STORE, k.trim()); }
  function clearKey()       { localStorage.removeItem(KEY_STORE); }
  function hasKey()         { return !!getKey(); }
  function getBaseUrl()     { return BASE_URL; }

  return { getKey, setKey, clearKey, hasKey, getBaseUrl };
})();
