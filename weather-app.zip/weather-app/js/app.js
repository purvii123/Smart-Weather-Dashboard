// ============================================================
// js/app.js — Main Application Controller
// ============================================================
// FIX: All async operations wrapped in try/catch with user-facing errors.
// FIX: API key setup flow with validation.
// FIX: Speech synthesis checks for browser support before calling.
// FIX: Chart lifecycle managed safely (null-guard before destroy).

let chart = null;  // Chart.js instance — managed here to prevent leaks

// ============================================================
// INIT
// ============================================================
window.addEventListener('DOMContentLoaded', () => {
  // Show/hide API setup banner based on saved key
  updateApiSetupVisibility();

  // Populate route origin datalist if needed (future upgrade hook)
  const cityInput = document.getElementById('cityInput');
  if (cityInput) cityInput.focus();
});

// ============================================================
// API KEY MANAGEMENT
// ============================================================
function saveApiKey() {
  const input = document.getElementById('apiKeyInput');
  const key = (input?.value || '').trim();
  if (!key) return showError('Please paste a valid API key first.');
  Config.setKey(key);
  updateApiSetupVisibility();
  showError(''); // clear any old error
}

function clearApiKey() {
  Config.clearKey();
  updateApiSetupVisibility();
}

function updateApiSetupVisibility() {
  const banner = document.getElementById('apiSetup');
  if (!banner) return;
  banner.style.display = Config.hasKey() ? 'none' : 'block';
}

// ============================================================
// MAIN WEATHER FETCH
// ============================================================
async function getWeather() {
  const city = (document.getElementById('cityInput')?.value || '').trim();
  if (!city) return showError('Please enter a city name.');

  showError('');
  setLoading(true);

  try {
    const w = await WeatherData.fetchWeather(city);

    // ---- Feed live data into KNN training set ----
    ML.addDataPoint(w.temp, w.humidity, w.weatherMain);

    // ---- Render weather card ----
    renderWeatherCard(w);

    // ---- Render ML panel ----
    renderMlPanel(w);

    // ---- Chart ----
    renderChart(w);

    // ---- Animations ----
    Anim.applyWeather(w.weatherMain);

    // ---- Voice (with support check) ----
    speakWeather(w);

  } catch (err) {
    handleError(err);
  } finally {
    setLoading(false);
  }
}

// ============================================================
// A* ROUTE
// ============================================================
function findBestRoute() {
  const goal = (document.getElementById('cityInput')?.value || '').trim();
  if (!goal) return showError('Enter a destination city to find a route.');

  const result = Routing.aStar('Delhi', goal);

  const routeEl = document.getElementById('routeResult');
  if (!routeEl) return;

  if (result.error) {
    routeEl.textContent = `⚠️ ${result.error}`;
    return;
  }

  const pathStr = result.path.join(' → ');
  routeEl.textContent = `${pathStr}\n(~${result.distance} km straight-line)`;

  // Show ML panel if hidden
  document.getElementById('mlPanel')?.classList.remove('hidden');

  speakText('Best route from Delhi to ' + goal + ' is ' + result.path.join(' to '));
}

// ============================================================
// RENDER HELPERS
// ============================================================
function renderWeatherCard(w) {
  const el = document.getElementById('result');
  if (!el) return;

  const now  = new Date();
  const date = now.toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'short' });
  const time = now.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' });
  const cacheNote = w.fromCache ? ' <span style="font-size:0.7rem;color:var(--warn)">(cached)</span>' : '';

  el.innerHTML = `
    <div class="result-header">
      <div>
        <div class="result-city">${escHtml(w.city)}, ${escHtml(w.country)}${cacheNote}</div>
      </div>
      <div class="result-datetime">${date}<br/>${time}</div>
    </div>
    <div class="result-temp">${w.temp}°C</div>
    <div class="result-desc">${escHtml(w.description)}</div>
    <div class="result-stats">
      <div class="stat-chip">
        <div class="label">Humidity</div>
        <div class="val">${w.humidity}%</div>
      </div>
      <div class="stat-chip">
        <div class="label">Wind</div>
        <div class="val">${w.wind} km/h</div>
      </div>
      <div class="stat-chip">
        <div class="label">Feels like</div>
        <div class="val">${w.feelsLike}°C</div>
      </div>
      <div class="stat-chip">
        <div class="label">Pressure</div>
        <div class="val">${w.pressure} hPa</div>
      </div>
      <div class="stat-chip">
        <div class="label">Visibility</div>
        <div class="val">${w.visibility !== null ? w.visibility + ' km' : 'N/A'}</div>
      </div>
      <div class="stat-chip">
        <div class="label">Lat / Lon</div>
        <div class="val" style="font-size:0.78rem">${w.lat.toFixed(2)}, ${w.lon.toFixed(2)}</div>
      </div>
    </div>
  `;
  el.classList.remove('hidden');
}

function renderMlPanel(w) {
  // KNN
  const knn = ML.knnPredict(w.temp, w.humidity);
  document.getElementById('knnResult').textContent = knn;

  // Heuristic (honest label)
  const heuristic = ML.tempHeuristic(w.temp, w.humidity);
  document.getElementById('regResult').textContent = heuristic;

  // Cluster (honest label)
  const cluster = ML.climateCluster(w.temp);
  document.getElementById('clusterResult').textContent = cluster;

  // Route placeholder (filled on button click)
  const routeEl = document.getElementById('routeResult');
  if (routeEl && routeEl.textContent === '—') {
    routeEl.textContent = 'Click "AI Route" to compute.';
  }

  document.getElementById('mlPanel')?.classList.remove('hidden');
}

function renderChart(w) {
  const ctx = document.getElementById('weatherChart');
  if (!ctx) return;

  // Safe destroy of previous instance
  if (chart !== null) {
    try { chart.destroy(); } catch(e) {}
    chart = null;
  }

  const labels = ['Morning', 'Late Morning', 'Afternoon', 'Evening', 'Night'];
  const temps  = WeatherData.estimateDailyCurve(w.temp);

  try {
    chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Temp (°C)',
          data: temps,
          borderColor: '#38bdf8',
          backgroundColor: 'rgba(56,189,248,0.12)',
          pointBackgroundColor: '#38bdf8',
          tension: 0.4,
          fill: true,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => `${ctx.parsed.y.toFixed(1)}°C`
            }
          }
        },
        scales: {
          x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#8892a4' } },
          y: {
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#8892a4', callback: v => v + '°C' }
          }
        }
      }
    });
  } catch(chartErr) {
    console.error('Chart render error:', chartErr);
  }

  document.getElementById('chartSection')?.classList.remove('hidden');
}

// ============================================================
// ERROR HANDLING
// ============================================================
function handleError(err) {
  const messages = {
    'NO_KEY':         'No API key saved. Enter your OpenWeatherMap key above.',
    'INVALID_KEY':    'API key rejected (401). Double-check your key at openweathermap.org.',
    'CITY_NOT_FOUND': 'City not found. Check spelling — try "New Delhi" or "Mumbai".',
    'NETWORK_ERROR':  'Network error. Check your internet connection and try again.',
  };

  const msg = messages[err.message] ||
    (err.message.startsWith('API_ERROR_')
      ? `API error (${err.message.replace('API_ERROR_', '')}). Try again later.`
      : `Unexpected error: ${err.message}`);

  showError(msg);
  console.error('[WeatherApp]', err);
}

function showError(msg) {
  const el = document.getElementById('errorBanner');
  if (!el) return;
  if (!msg) { el.classList.add('hidden'); return; }
  el.textContent = `⚠️ ${msg}`;
  el.classList.remove('hidden');
}

// ============================================================
// LOADING STATE
// ============================================================
function setLoading(on) {
  const btn = document.querySelector('button[onclick="getWeather()"]');
  if (!btn) return;
  btn.innerHTML = on
    ? '<span class="spinner"></span>Loading…'
    : 'Check Weather';
  btn.disabled = on;
}

// ============================================================
// VOICE (safe — checks browser support)
// ============================================================
function speakWeather(w) {
  speakText(`Weather in ${w.city}: ${w.temp} degrees Celsius, ${w.description}. Humidity ${w.humidity} percent.`);
}

function speakText(text) {
  try {
    if (!('speechSynthesis' in window)) return; // not supported — silently skip
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    utt.rate  = 0.95;
    utt.pitch = 1;
    window.speechSynthesis.speak(utt);
  } catch(e) {
    console.warn('Speech synthesis error:', e);
  }
}

// ============================================================
// UTILITY
// ============================================================
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
