// ============================================================
// js/ml.js — Machine Learning & Heuristic Analysis
// ============================================================
//
// FIXES applied:
//  1. KNN now trains on LIVE API data accumulated this session
//     (falls back to seed dataset on first load).
//  2. Regression replaced with an HONEST rule-based heuristic —
//     clearly labeled in the UI, not called "ML".
//  3. Clustering is now honestly labeled as a threshold rule,
//     not presented as k-means.
//
// HONEST LABELING:
//  - "Real Algorithm" badge  → KNN (real distance-based classification)
//  - "Rule-Based" badge      → Temp heuristic, climate cluster
//    (threshold if-else logic; no model training)

const ML = (() => {

  // ---- Seed dataset (used until enough live data is accumulated) ----
  // These are representative values; KNN improves as more cities are fetched.
  let dataset = [
    { features: [10, 60], label: 'Cold'     },
    { features: [15, 70], label: 'Cold'     },
    { features: [20, 55], label: 'Cool'     },
    { features: [24, 50], label: 'Pleasant' },
    { features: [26, 55], label: 'Pleasant' },
    { features: [28, 40], label: 'Warm'     },
    { features: [30, 35], label: 'Sunny'    },
    { features: [32, 30], label: 'Hot'      },
    { features: [34, 25], label: 'Hot'      },
    { features: [36, 20], label: 'Scorching'},
    { features: [29, 75], label: 'Humid'    },
    { features: [33, 80], label: 'Humid'    },
    { features: [27, 60], label: 'Cloudy'   },
    { features: [23, 75], label: 'Rainy'    },
    { features: [18, 80], label: 'Rainy'    },
  ];

  // ---- Add a real data point from API response to the training set ----
  function addDataPoint(temp, humidity, label) {
    // Avoid exact duplicates
    const exists = dataset.some(
      d => d.features[0] === temp && d.features[1] === humidity
    );
    if (!exists) {
      dataset.push({ features: [temp, humidity], label });
    }
  }

  // ---- Euclidean distance ----
  function _distance(a, b) {
    return Math.sqrt(
      Math.pow(a[0] - b[0], 2) + Math.pow(a[1] - b[1], 2)
    );
  }

  // ---- KNN Classifier (k = 3) ----
  // REAL ALGORITHM: finds k nearest neighbours and majority-votes their label.
  function knnPredict(temp, humidity, k = 3) {
    if (dataset.length < k) return 'Insufficient data';

    const distances = dataset.map(point => ({
      label: point.label,
      dist:  _distance([temp, humidity], point.features)
    }));

    distances.sort((a, b) => a.dist - b.dist);

    const votes = {};
    for (let i = 0; i < k; i++) {
      const lbl = distances[i].label;
      votes[lbl] = (votes[lbl] || 0) + 1;
    }

    const winner = Object.keys(votes).reduce((a, b) => votes[a] > votes[b] ? a : b);
    const confidence = Math.round((votes[winner] / k) * 100);

    return `${winner} (${confidence}% confidence, k=${k}, n=${dataset.length})`;
  }

  // ---- Temperature Feel Heuristic ----
  // RULE-BASED — NOT a trained regression model.
  // Named honestly in the UI as "Temp Heuristic".
  function tempHeuristic(temp, humidity) {
    const heatIndex = temp + (humidity > 60 ? (humidity - 60) * 0.1 : 0);

    if (heatIndex >= 40) return `Extremely hot (heat index ~${heatIndex.toFixed(1)}°C)`;
    if (heatIndex >= 35) return `Very hot (heat index ~${heatIndex.toFixed(1)}°C)`;
    if (heatIndex >= 30) return `Hot (feels like ~${heatIndex.toFixed(1)}°C)`;
    if (heatIndex >= 25) return `Warm (feels like ~${heatIndex.toFixed(1)}°C)`;
    if (heatIndex >= 18) return `Comfortable (~${heatIndex.toFixed(1)}°C)`;
    if (heatIndex >= 10) return `Cool (~${heatIndex.toFixed(1)}°C)`;
    return `Cold (~${heatIndex.toFixed(1)}°C)`;
  }

  // ---- Climate Cluster Heuristic ----
  // RULE-BASED — NOT k-means. Three temperature bands only.
  function climateCluster(temp) {
    if (temp >= 35) return '🔥 Arid / Hot Region  (≥35°C band)';
    if (temp >= 28) return '🌤️ Subtropical Region (28–34°C band)';
    if (temp >= 18) return '🌿 Temperate Region   (18–27°C band)';
    if (temp >= 8)  return '❄️  Cool Region        (8–17°C band)';
    return                  '🧊 Cold / Polar Region (<8°C band)';
  }

  return { knnPredict, tempHeuristic, climateCluster, addDataPoint };
})();
