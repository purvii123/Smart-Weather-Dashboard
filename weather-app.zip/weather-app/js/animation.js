
const Anim = (() => {

  const container = () => document.getElementById('animationContainer');

  function clear() {
    try { container().innerHTML = ''; } catch(e) {}
  }

  function rain() {
    clear();
    try {
      const c = container();
      for (let i = 0; i < 70; i++) {
        const d = document.createElement('div');
        d.className = 'rain-drop';
        d.style.left     = `${Math.random() * 100}vw`;
        d.style.animationDuration  = `${0.4 + Math.random() * 0.6}s`;
        d.style.animationDelay     = `${Math.random() * 1}s`;
        d.style.height   = `${12 + Math.random() * 10}px`;
        c.appendChild(d);
      }
    } catch(e) { console.warn('Animation error (rain):', e); }
  }

  function snow() {
    clear();
    try {
      const c = container();
      for (let i = 0; i < 50; i++) {
        const s = document.createElement('div');
        s.className = 'snow-flake';
        s.style.left   = `${Math.random() * 100}vw`;
        s.style.width  = s.style.height = `${4 + Math.random() * 5}px`;
        s.style.animationDuration  = `${2 + Math.random() * 3}s`;
        s.style.animationDelay     = `${Math.random() * 2}s`;
        c.appendChild(s);
      }
    } catch(e) { console.warn('Animation error (snow):', e); }
  }

  function clouds() {
    clear();
    try {
      const c = container();
      for (let i = 0; i < 6; i++) {
        const cl = document.createElement('div');
        cl.className = 'cloud-puff';
        cl.style.top  = `${10 + Math.random() * 160}px`;
        cl.style.animationDuration = `${18 + Math.random() * 20}s`;
        cl.style.animationDelay    = `${-Math.random() * 20}s`;
        cl.style.opacity = `${0.04 + Math.random() * 0.06}`;
        c.appendChild(cl);
      }
    } catch(e) { console.warn('Animation error (clouds):', e); }
  }

  // Maps OpenWeatherMap weatherMain to animation + background colour
  const BG_MAP = {
    'Thunderstorm': { fn: rain,   bg: '#06080f' },
    'Drizzle':      { fn: rain,   bg: '#0d1520' },
    'Rain':         { fn: rain,   bg: '#0d1520' },
    'Snow':         { fn: snow,   bg: '#1a1e2e' },
    'Mist':         { fn: clouds, bg: '#111827' },
    'Fog':          { fn: clouds, bg: '#111827' },
    'Haze':         { fn: clouds, bg: '#12151c' },
    'Dust':         { fn: clouds, bg: '#1a1408' },
    'Smoke':        { fn: clouds, bg: '#111111' },
    'Clouds':       { fn: clouds, bg: '#111827' },
    'Clear':        { fn: clouds, bg: '#0b1422' },
    'default':      { fn: clouds, bg: '#0b1120' },
  };

  function applyWeather(weatherMain) {
    try {
      const entry = BG_MAP[weatherMain] || BG_MAP['default'];
      entry.fn();
      document.body.style.background = entry.bg;
    } catch(e) { console.warn('applyWeather error:', e); }
  }

  return { clear, rain, snow, clouds, applyWeather };
})();
