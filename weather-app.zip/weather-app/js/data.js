// ============================================================
// js/data.js — Real Weather Data via OpenWeatherMap API
// ============================================================
// FIX: Replaces the static hardcoded data object with live API calls.
// UPGRADE: Adds localStorage cache (10-min TTL) to avoid hammering
// the free-tier rate limit.

const WeatherData = (() => {
  const CACHE_PREFIX = 'weather_cache_';
  const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes

  // ---- Cache helpers ----
  function _readCache(city) {
    try {
      const raw = localStorage.getItem(CACHE_PREFIX + city.toLowerCase());
      if (!raw) return null;
      const { ts, data } = JSON.parse(raw);
      if (Date.now() - ts > CACHE_TTL_MS) {
        localStorage.removeItem(CACHE_PREFIX + city.toLowerCase());
        return null;
      }
      return data;
    } catch { return null; }
  }

  function _writeCache(city, data) {
    try {
      localStorage.setItem(
        CACHE_PREFIX + city.toLowerCase(),
        JSON.stringify({ ts: Date.now(), data })
      );
    } catch { /* quota exceeded — silently skip */ }
  }

  // ---- Main fetch ----
  async function fetchWeather(city) {
    // 1. Try cache first
    const cached = _readCache(city);
    if (cached) return { ...cached, fromCache: true };

    // 2. Validate API key
    if (!Config.hasKey()) {
      throw new Error('NO_KEY');
    }

    // 3. Call OpenWeatherMap current weather endpoint
    const url = `${Config.getBaseUrl()}/weather?q=${encodeURIComponent(city)}&appid=${Config.getKey()}&units=metric`;

    let response;
    try {
      response = await fetch(url);
    } catch (networkErr) {
      throw new Error('NETWORK_ERROR');
    }

    if (response.status === 401) throw new Error('INVALID_KEY');
    if (response.status === 404) throw new Error('CITY_NOT_FOUND');
    if (!response.ok)            throw new Error(`API_ERROR_${response.status}`);

    const json = await response.json();

    // 4. Normalise to our internal shape
    const normalised = {
      city:        json.name,
      country:     json.sys.country,
      temp:        Math.round(json.main.temp),
      feelsLike:   Math.round(json.main.feels_like),
      humidity:    json.main.humidity,
      wind:        Math.round(json.wind.speed * 3.6), // m/s → km/h
      windRaw:     json.wind.speed,
      description: json.weather[0].description,
      weatherMain: json.weather[0].main,   // e.g. "Rain", "Clear", "Snow"
      icon:        json.weather[0].icon,
      lat:         json.coord.lat,
      lon:         json.coord.lon,
      pressure:    json.main.pressure,
      visibility:  json.visibility ? Math.round(json.visibility / 1000) : null,
      fromCache:   false
    };

    // 5. Write to cache
    _writeCache(city, normalised);

    return normalised;
  }

  // ---- 5-step daily estimate (morning→night) from current temp ----
  // These are estimates only — not a forecast API call.
  function estimateDailyCurve(currentTemp) {
    return [
      +(currentTemp - 4).toFixed(1),  // Morning
      +(currentTemp - 1).toFixed(1),  // Late morning
      +(currentTemp + 2).toFixed(1),  // Afternoon (peak)
      +(currentTemp + 0).toFixed(1),  // Evening
      +(currentTemp - 3).toFixed(1),  // Night
    ];
  }

  return { fetchWeather, estimateDailyCurve };
})();
