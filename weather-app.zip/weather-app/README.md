# 🌤️ Smart Weather App

A real-data weather app with honest ML labeling, fixed A* routing, and full error handling.

---

## 📁 Project Structure

```
weather-app/
├── index.html          ← Main HTML page
├── style.css           ← All styles
├── README.md           ← This file
└── js/
    ├── config.js       ← API key management (localStorage)
    ├── data.js         ← Real OpenWeatherMap API + caching
    ├── ml.js           ← KNN classifier + honest heuristics
    ├── routing.js      ← A* with haversine heuristic (fixed)
    ├── animation.js    ← Weather animations (rain/snow/clouds)
    └── app.js          ← Main controller, error handling, UI
```

---

## ✅ Fixes Applied (from Sr. Analyst Report)

| Issue | Status | How Fixed |
|---|---|---|
| Static hardcoded data | ✅ Fixed | Now calls OpenWeatherMap live API |
| Fake regression | ✅ Fixed | Honest `tempHeuristic()` — clearly labeled "Rule-Based" in UI |
| Fake k-means | ✅ Fixed | Honest `climateCluster()` — clearly labeled "Rule-Based" in UI |
| A* inadmissible heuristic | ✅ Fixed | `h(n) = haversine(n, goal)` — admissible ✓ |
| Delhi hardcoded as only origin | ✅ Fixed | Any city in graph can be origin |
| Zero error handling | ✅ Fixed | All async ops in try/catch, user-facing error banners |
| Chart memory leak | ✅ Fixed | Null-guard + safe `.destroy()` before re-render |
| Speech synthesis no support check | ✅ Fixed | Checks `'speechSynthesis' in window` before calling |
| KNN trains on same data it reads | ✅ Fixed | Seed dataset + live API data accumulates each session |

---

## 🚀 How to Run in VS Code — Step by Step

### Step 1: Install VS Code
Download from https://code.visualstudio.com and install it.

### Step 2: Open the Project Folder
1. Open VS Code
2. Click **File → Open Folder**
3. Select the `weather-app` folder you downloaded
4. You should see all files in the Explorer panel on the left

### Step 3: Install the Live Server Extension
This lets you run the app in your browser with one click.

1. Press `Ctrl+Shift+X` (Windows/Linux) or `Cmd+Shift+X` (Mac) to open Extensions
2. Search: **Live Server**
3. Click **Install** on the extension by Ritwick Dey

### Step 4: Get a Free OpenWeatherMap API Key
1. Go to https://openweathermap.org/api
2. Click **Sign Up** (free account)
3. After signing up, go to **API Keys** tab in your dashboard
4. Copy your default API key (looks like: `a1b2c3d4e5f6...`)
5. ⚠️ New keys take **10–15 minutes** to activate after signup

### Step 5: Launch the App
1. In VS Code, right-click `index.html` in the Explorer panel
2. Click **"Open with Live Server"**
3. Your browser opens at `http://127.0.0.1:5500`

### Step 6: Enter Your API Key in the App
1. You'll see a yellow setup banner at the top
2. Paste your OpenWeatherMap API key into the input box
3. Click **Save Key**
4. The banner disappears — you're ready!

### Step 7: Use the App
- Type a city name (e.g., `Ludhiana`) and click **Check Weather**
- The app fetches real live weather data
- See ML analysis, chart, and animations
- Click **AI Route** to find the A* path from Delhi to your city

---

## ⚠️ Common Problems & Solutions

| Problem | Solution |
|---|---|
| "API key rejected (401)" | Wait 15 min after signup for key to activate, then retry |
| "City not found" | Use English names: "New Delhi", "Bangalore", "Mumbai" |
| No sound/voice | Some browsers block autoplay audio. Click the page first. |
| Weather not updating | Cached for 10 min. Click "Change Key" to force refresh, or wait. |
| Blank page in VS Code | Don't open index.html directly — use Live Server (Step 5) |
| CORS error in console | You're opening the file directly (file://). Must use Live Server. |

---

## 🔧 How the ML Components Work (Honest Labels)

### ✅ KNN Classifier — Real Algorithm
- Computes Euclidean distance from (temp, humidity) to all training points
- Votes among k=3 nearest neighbours
- Training set grows as you look up more cities in a session
- Output: predicted weather category + confidence %

### ⚠️ Temperature Heuristic — Rule-Based (NOT regression)
- Simple if-else on adjusted heat index (temp + humidity modifier)
- Not a trained model — no coefficients, no fitting
- Honestly labeled in the UI

### ⚠️ Climate Cluster — Rule-Based (NOT k-means)
- Five temperature bands with fixed thresholds
- Honestly labeled in the UI

### ✅ A* Routing — Real Algorithm
- Haversine straight-line distance as h(n) — admissible heuristic
- gScore = cumulative geographic distance along path
- Works for any two cities in the graph (not just from Delhi)

---

## 📦 No npm or Node.js Required
This app uses only vanilla HTML/CSS/JS with two CDN libraries:
- **Chart.js** — loaded from cdn.jsdelivr.net
- **Google Fonts** — loaded from fonts.googleapis.com

No build step, no package.json, no terminal commands needed.
